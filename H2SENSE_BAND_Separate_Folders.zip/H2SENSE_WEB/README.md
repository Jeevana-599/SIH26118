# H₂S SENSE BAND — SIH26118 Web Prototype

Open `index.html` in a browser. It is a no-build HTML/CSS/JS prototype containing the PPT-described solution flow: overview, smartphone scan, reference calibration, synthetic dose estimate, worker records, EHS dashboard, architecture, validation roadmap and research basis.

The dose function in `app.js` is a UI-only synthetic mapping. It is NOT a validated H₂S exposure model. Replace it with a validated model trained from controlled exposure data and qualified reference measurements before any safety use.

Source basis: supplied SIH26118 problem-description PDF and SIH presentation.
